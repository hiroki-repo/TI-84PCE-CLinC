﻿// TI-84PCECLinC.cpp : アプリケーションのエントリ ポイントを定義します。
//

#include "core/cemu.h"

#include "framework.h"
#include "TI-84PCECLinC.h"

#include "core/cpu.h"

#include <stdio.h>
#include <windows.h>
#include <tchar.h>
#include "framework.h"

#include <stdlib.h>
#include <time.h>

#include <CommCtrl.h>

#include "commdlg.h"

//------------------------------------------------------
//■関数 OpenDiaog
//■用途 「ファイルを開く」ダイアログを表示する
//■引数
//        hwnd       ...親ウインドウのハンドル
//        Filter     ...フィルター
//        FileName   ...ファイルのフルパス名(戻り値)
//        Flags      ...ダイアログのフラグ
//■戻り値
//      ファイルを選択  true   
//------------------------------------------------------
int OpenDiaog(HWND hwnd, LPCSTR Filter, char* FileName, DWORD Flags)
{
    OPENFILENAMEA OFN;

    ZeroMemory(&OFN, sizeof(OPENFILENAMEA));
    OFN.lStructSize = sizeof(OPENFILENAMEA);
    OFN.hwndOwner = hwnd;
    OFN.lpstrFilter = Filter;
    OFN.lpstrFile = FileName;
    OFN.nMaxFile = MAX_PATH * 200;
    OFN.Flags = Flags;
    OFN.lpstrTitle = "ファイルを開く";
    return (GetOpenFileNameA(&OFN));
}

void* pBit;

HDC srchdc;
HBITMAP hbDib;
HDC hdc;
HBITMAP hbOld;

HWND hwnd4mw;
HDC hCDC;
HBITMAP hOldCBitmap;
HBITMAP hCBitmap;

HANDLE Z80Threadid = 0;
HANDLE BSThreadid = 0;
HANDLE BGThreadid = 0;
HANDLE RTIThreadid = 0;
HANDLE BATThreadid = 0;

SYSTEM_POWER_STATUS Realbatterystate;

bool isharftoneenabled = false;

#define MAX_LOADSTRING 100

// グローバル変数:
HINSTANCE hInst;                                // 現在のインターフェイス
WCHAR szTitle[MAX_LOADSTRING];                  // タイトル バーのテキスト
WCHAR szWindowClass[MAX_LOADSTRING];            // メイン ウィンドウ クラス名

// このコード モジュールに含まれる関数の宣言を転送します:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

//static const cemu_sdl_key_t* keymap = cemu_keymap;
static asic_rev_t asic_rev = ASIC_REV_AUTO;
static int8_t python_rev = -1;

UINT8 keyseedime[512] = { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0B,0x00,0x00,0x00,0x00,0x05,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x8E,0x00,0x00,0x00,0x2D,0x02,0x03,0x01,0x04,0x00,0x00,0x00,0x00,0x0A,0x0B,0x00,0x8E,0x8F,0x90,0x91,0x92,0x93,0x94,0x95,0x96,0x97,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xEA,0xEB,0xEC,0xED,0xEE,0xF0,0xF1,0xF2,0xF3,0xF5,0xF6,0xF7,0xF8,0xF9,0xFA,0xFB,0xFC,0x00,0x00,0x00,0x27,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x49,0x48,0x2E,0x5A,0x44,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x09,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC6,0x00,0x8B,0x81,0x8B,0x83,0x82,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x88,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x06,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x07,0x00,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x86,0x00,0x00,0x00,0x00,0x00,0xF0,0x00,0xEC,0x85,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x9A,0x9B,0x9C,0x9D,0x9E,0x9F,0xA0,0xA1,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0xAA,0xAB,0xAC,0xAD,0xAE,0xAF,0xB0,0xB1,0xB2,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0xC6,0x00,0x00,0x00,0x00,0xEC,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xED,0x00,0x00,0x00,0x00,0x00,0x00,0x99,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };
UINT8 keyseed[512]    = { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x38,0x00,0x00,0x00,0x00,0x09,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x09,0x00,0x00,0x00,0x00,0x21,0x36,0x30,0x00,0x1F,0x02,0x04,0x03,0x01,0x00,0x00,0x00,0x00,0x00,0x29,0x00,0x21,0x22,0x1A,0x12,0x23,0x1B,0x13,0x24,0x1C,0x14,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x2F,0x27,0x1F,0x2E,0x26,0x1E,0x16,0x0E,0x2D,0x25,0x1D,0x15,0x0D,0x2C,0x24,0x1C,0x14,0x0C,0x2B,0x23,0x1B,0x13,0x0B,0x2A,0x22,0x1A,0x00,0x00,0x27,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x35,0x34,0x33,0x32,0x31,0x28,0x20,0x17,0x47,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x19,0x00,0x25,0x0B,0x19,0x0D,0x0C,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0B,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x15,0x00,0x00,0x00,0x00,0x00,0x0E,0x00,0x0C,0x1D,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x2F,0x27,0x1F,0x2E,0x26,0x1E,0x16,0x0E,0x2D,0x25,0x1D,0x15,0x0D,0x2C,0x24,0x1C,0x14,0x0C,0x2B,0x23,0x1B,0x13,0x0B,0x2A,0x22,0x1A,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0A,0x19,0x00,0x11,0x00,0x11,0x1D,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x15,0x00,0x00,0x00,0x00,0x00,0x00,0x21,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };

extern "C" {

void emu_lcd_drawframe(void* output);

asic_rev_t gui_handle_reset(const boot_ver_t* boot_ver, asic_rev_t loaded_rev, asic_rev_t default_rev, bool* python) {
    (void)boot_ver;
    (void)loaded_rev;
    (void)default_rev;
    if (python_rev >= 0) {
        *python = python_rev;
    }
    return asic.revision;
}
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: ここにコードを挿入してください。

    // グローバル文字列を初期化する
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_TI84PCECLINC, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // アプリケーション初期化の実行:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TI84PCECLINC));

    MSG msg;

    // メイン メッセージ ループ:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  関数: MyRegisterClass()
//
//  目的: ウィンドウ クラスを登録します。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TI84PCECLINC));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_TI84PCECLINC);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

void run_emu(LPVOID* arg4dbg) {
    SYSTEMTIME st_st; SYSTEMTIME st_goal; int ststgoal16;
    while (true) {
        //emu_run(sched.clockRates[CLOCK_CPU] / 60);
        GetSystemTime(&st_st);
        emu_run(1);
        GetSystemTime(&st_goal); ststgoal16 = (st_goal.wMilliseconds) - (st_st.wMilliseconds); if (ststgoal16 < 0) { ststgoal16 += 1000; } if (ststgoal16 < 5) { Sleep(5 - ststgoal16); }
    }
}

void Drawbackground(LPVOID* arg4dbg) {
    SYSTEMTIME st_st; SYSTEMTIME st_goal; int ststgoal16;
    RECT rw4rend;
    char grptmp[320 * 240 * 4];
    while (true) {
        GetSystemTime(&st_st);
        UINT32* pbitred = (UINT32*)pBit;
        for (int cnt = 0; cnt < (320 * 240); cnt++) { *pbitred++ = 0xFF000000; }
        emu_lcd_drawframe((void*)&grptmp);
        for (int cnt2 = 0; cnt2 < 240; cnt2++) { memcpy((void*)((UINT64)pBit+((UINT64)320*4*(239-cnt2))), (void*)((UINT64)((UINT64)&grptmp) + ((UINT64)320 * 4 * (cnt2))),320*4); }
        GetClientRect(hwnd4mw, &rw4rend);
        SetStretchBltMode(srchdc, (isharftoneenabled ? STRETCH_HALFTONE : COLORONCOLOR)); StretchBlt(srchdc, 0, 0, rw4rend.right, rw4rend.bottom, hCDC, 0, 0, 320, 240, SRCCOPY); if (isharftoneenabled == true) { SetBrushOrgEx(srchdc, 0, 0, NULL); }
        GetSystemTime(&st_goal); ststgoal16 = (st_goal.wMilliseconds) - (st_st.wMilliseconds); if (ststgoal16 < 0) { ststgoal16 += 1000; } if (ststgoal16 < 17) { Sleep(17 - ststgoal16); }
    }
}

void BatteryRoutine(LPVOID* arg4dbg) {
    while (true) {
        GetSystemPowerStatus(&Realbatterystate);
        control.batteryCharging = (Realbatterystate.ACLineStatus != 0);
        control.setBatteryStatus = ((Realbatterystate.BatteryLifePercent / 20) + 1);
        Sleep(16);
        //cpu.abort = CPU_ABORT_EXIT;
    }
}

//
//   関数: InitInstance(HINSTANCE, int)
//
//   目的: インスタンス ハンドルを保存して、メイン ウィンドウを作成します
//
//   コメント:
//
//        この関数で、グローバル変数でインスタンス ハンドルを保存し、
//        メイン プログラム ウィンドウを作成および表示します。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // グローバル変数にインスタンス ハンドルを格納する

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   hwnd4mw = hWnd;
   srchdc = GetDC(hWnd);

   if (!hWnd)
   {
      return FALSE;
   }

   BITMAPINFOHEADER* pbi;
   pbi = (LPBITMAPINFOHEADER)GlobalAlloc(GPTR, sizeof(BITMAPINFOHEADER));
   pbi->biBitCount = 32;

   pbi->biSize = sizeof(BITMAPINFOHEADER);
   pbi->biWidth = 320;
   pbi->biHeight = 240;
   pbi->biPlanes = 1;

   hbDib = CreateDIBSection(srchdc, (BITMAPINFO*)pbi, DIB_RGB_COLORS, (void**)&pBit, NULL, 0);
   hdc = CreateCompatibleDC(srchdc);
   hCDC = hdc;
   hbOld = (HBITMAP)SelectObject(hdc, hbDib);
   //ReleaseDC(hWnd, srchdc);

   if (pBit == 0) { TerminateProcess(0,0); }

   hOldCBitmap = (HBITMAP)SelectObject(hCDC, hCBitmap);

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   asic_free();
   asic_init();
   asic_reset();

   emu_load(EMU_DATA_ROM,"firmware.bin");

   cpu.abort = 0;

   Z80Threadid = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)run_emu, 0, 0, 0);
   BGThreadid = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)Drawbackground, 0, 0, 0);
   BATThreadid = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)BatteryRoutine, 0, 0, 0);

   return TRUE;
}

bool stillsendprogress = false;

bool progressHandler(void* context, int value, int total) {
    if (value == 1 && total == 1) {
        stillsendprogress = false;
    }
    return false;
}

void fileselector(HWND hWnd) {
    char FileName[MAX_PATH * 200];
    //初期化(これをしないとごみが入る)
    ZeroMemory(FileName, MAX_PATH * 200);
    wchar_t CurrentDirectoryofEmu[MAX_PATH * 2];
    ZeroMemory(CurrentDirectoryofEmu, MAX_PATH * 2);
    GetCurrentDirectoryW(MAX_PATH * 2, CurrentDirectoryofEmu);
    //「ファイルを開く」ダイアログを表示
    if (OpenDiaog(hWnd, "TI-84 Variables(*.8??)\0*.8??\0All Files(*.*)\0*.*\0\0",
        FileName, OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_ALLOWMULTISELECT | OFN_EXPLORER)) {
        //MessageBoxA(0, FileName,"A", 0);
        char* Fnx = FileName;
        char* Fnx2 = Fnx;
        char Fnx3[MAX_PATH * 2];
        char* Fnx4[512];
        ZeroMemory(Fnx3, MAX_PATH * 2);
        int cnt = 0;
        int cntx = 0;
        do {
            cnt += (strlen(Fnx2) + 1);
            Fnx2 = &Fnx[cnt];
            if ((strlen(Fnx2) == 0) && (cntx == 0)) {
                emu_send_variable(FileName, LINK_FILE);
                break;
            }
            else {
                ZeroMemory(Fnx3, MAX_PATH * 2);
                if (Fnx2[1] == ':') {
                    memcpy(Fnx3, Fnx2, strlen(Fnx2));
                }
                else {
                    memcpy(Fnx3, FileName, strlen(FileName));
                    if (FileName[strlen(FileName) - 1] != '\\' && FileName[strlen(FileName) - 1] != '/') {
                        strcat(Fnx3, "\\");
                    }
                    strcat(Fnx3, Fnx2);
                }
                Fnx4[cntx] = (char*)malloc(MAX_PATH * 2);
                if (Fnx4[cntx] != 0) { memcpy(Fnx4[cntx], Fnx3, (MAX_PATH * 2)); }
            }
            cntx++;
        } while (Fnx2[0] != 0);
        if (cntx > 0) {
            for (int cnt2 = 0; cnt2 < cntx; cnt2++) {
                if (Fnx4[cnt2] != 0) {
                    stillsendprogress = true;
                    emu_send_variables((const char* const*)&Fnx4[cnt2], 1, LINK_FILE, &progressHandler, NULL);
                    while (stillsendprogress == true) { Sleep(1); }
                }
            }
        }
        for (int cnt2 = 0; cnt2 < cntx; cnt2++) {
            if (Fnx4[cnt2] != 0) { free(Fnx4[cnt2]); Fnx4[cnt2] = 0; }
        }
    }
    SetCurrentDirectoryW(CurrentDirectoryofEmu);
}

bool shiftpushed = false;
UINT8 ctrloraltpushed = 0;

//
//  関数: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  目的: メイン ウィンドウのメッセージを処理します。
//
//  WM_COMMAND  - アプリケーション メニューの処理
//  WM_PAINT    - メイン ウィンドウを描画する
//  WM_DESTROY  - 中止メッセージを表示して戻る
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 選択されたメニューの解析:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                emu_save(EMU_DATA_ROM, "firmware.bin");
                DestroyWindow(hWnd);
                break;
            case ID_32771:
                CreateThread(0,65536,(LPTHREAD_START_ROUTINE)&fileselector,hWnd,0,0);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: HDC を使用する描画コードをここに追加してください...
            //Rectangle(hdc, 0, 0, 640, 480);  // 描画
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
        if (wParam == 0x11) {
            ctrloraltpushed |= 1;
        }
        else if (wParam == 0x12) {
            ctrloraltpushed |= 2;
        }
        else {
            if (ctrloraltpushed == 0) {
                if (wParam == 0x10) { shiftpushed = true; }
                if (wParam == 219 || wParam == 192) { emu_keypad_event(1, 5, true); Sleep(32); }
                if ((wParam >= 0x41 && wParam <= 0x5a) || ((wParam == 187) && shiftpushed == false) || ((wParam == 187 || wParam == 186 || wParam == 191 || wParam == 32) && shiftpushed == true)) { emu_keypad_event(2, 7, true); Sleep(32); }
                if (keyseed[wParam | (shiftpushed ? 256 : 0)] != 0) {
                    emu_keypad_event(7 - ((keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) / 8), (keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) % 8, true);
                }
            }
            else {
                if (ctrloraltpushed & 1) {
                    if (!(wParam >= 0x41 && wParam <= 0x5a)) {
                        emu_keypad_event(2, 7, true); Sleep(32);
                    }
                }
                if (ctrloraltpushed & 2) {
                    emu_keypad_event(1, 5, true); Sleep(32);
                }
                if (wParam == 188) {
                }
                else if (keyseed[wParam | (shiftpushed ? 256 : 0)] != 0) {
                    emu_keypad_event(7 - ((keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) / 8), (keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) % 8, true);
                }
            }
        }
        break;
    case WM_KEYUP:
    case WM_SYSKEYUP:
        if (wParam == 0x11) {
            ctrloraltpushed &= ~(1);
        }
        else if (wParam == 0x12) {
            ctrloraltpushed &= ~(2);
        }
        else {
            if (ctrloraltpushed == 0) {
                if (wParam == 219 || wParam == 192) { emu_keypad_event(1, 5, false); Sleep(32); }
                if ((wParam >= 0x41 && wParam <= 0x5a) || ((wParam == 186) && shiftpushed == false) || ((wParam == 187 || wParam == 186 || wParam == 191 || wParam == 32) && shiftpushed == true)) { emu_keypad_event(2, 7, false); Sleep(32); }
                if (keyseed[wParam | (shiftpushed ? 256 : 0)] != 0) {
                    emu_keypad_event(7 - ((keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) / 8), (keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) % 8, false);
                }
                if (wParam == 0x10) { shiftpushed = false; }
            }
            else {
                if (ctrloraltpushed & 1) {
                    if (!(wParam >= 0x41 && wParam <= 0x5a)) {
                        emu_keypad_event(2, 7, false); Sleep(32);
                    }
                }
                if (ctrloraltpushed & 2) {
                    emu_keypad_event(1, 5, false); Sleep(32);
                }
                if (wParam == 188) {
                }
                else if (keyseed[wParam | (shiftpushed ? 256 : 0)] != 0) {
                    emu_keypad_event(7 - ((keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) / 8), (keyseed[wParam | (shiftpushed ? 256 : 0)] - 1) % 8, false);
                }
            }
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_CLOSE:
        if (hWnd == hwnd4mw) { emu_save(EMU_DATA_ROM,"firmware.bin"); }
        return DefWindowProc(hWnd, message, wParam, lParam);
        break;
    case 0x8000:
        emu_keypad_event(7 - ((wParam) / 8), (wParam) % 8, ((lParam == 0) ? false : true));
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// バージョン情報ボックスのメッセージ ハンドラーです。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
