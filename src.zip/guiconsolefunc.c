

void gui_console_printf(const char prm_0, ...) { return; }